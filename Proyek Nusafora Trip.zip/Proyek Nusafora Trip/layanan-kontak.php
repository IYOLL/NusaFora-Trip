<?php

// Variabel untuk menyimpan pesan status
$statusMsg = '';

// -------------------------------------------------------------------
// LANGKAH 1: Cek status dari URL (Metode GET setelah redirect)
// -------------------------------------------------------------------
// Ini akan kör di-load setelah browser di-redirect
if (isset($_GET['status'])) {
    if ($_GET['status'] == 'sukses') {
        $statusMsg = '<div class="status-msg success">Pesan Anda berhasil terkirim dan telah kami catat!</div>';
    } elseif ($_GET['status'] == 'gagal') {
        $statusMsg = '<div class="status-msg error">Terjadi kesalahan di server. Pesan Anda tidak dapat disimpan.</div>';
    } elseif ($_GET['status'] == 'validasi_gagal') {
         $statusMsg = '<div class="status-msg error">Harap isi semua field dengan benar.</div>';
    }
}


// -------------------------------------------------------------------
// LANGKAH 2: Cek apakah form disubmit (Metode POST)
// -------------------------------------------------------------------
// Ini hanya akan kör saat tombol "Kirim Pesan" ditekan
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Ambil data dari form dan bersihkan
    $nama = strip_tags(trim($_POST["nama"]));
    $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
    $pesan = strip_tags(trim($_POST["pesan"]));

    // Validasi: Cek apakah ada field yang kosong
    if (empty($nama) || !filter_var($email, FILTER_VALIDATE_EMAIL) || empty($pesan)) {
        
        // --- GAGAL VALIDASI ---
        // Redirect kembali ke form dengan status error validasi
        header('Location: layanan-kontak.php?status=validasi_gagal#kontak');
        exit(); // Penting!

    } else {
        
        // --- LOLOS VALIDASI: PROSES SIMPAN KE FILE ---

        $fileTujuan = 'database_pesan.txt';
        $tanggal = date("Y-m-d H:i:s"); // Tambahkan timestamp
        $dataUntukDisimpan = "===================================\n";
        $dataUntukDisimpan .= "Tanggal: " . $tanggal . "\n";
        $dataUntukDisimpan .= "Nama   : " . $nama . "\n";
        $dataUntukDisimpan .= "Email  : " . $email . "\n";
        $dataUntukDisimpan .= "Pesan  :\n" . $pesan . "\n";
        $dataUntukDisimpan .= "===================================\n\n";

        // Coba simpan data ke file
        if (file_put_contents($fileTujuan, $dataUntukDisimpan, FILE_APPEND | LOCK_EX)) {
            
            // --- BERHASIL DISIMPAN ---
            // Redirect ke halaman ini sendiri dengan status 'sukses'
            header('Location: layanan-kontak.php?status=sukses#kontak');
            exit(); // Penting!

        } else {
            
            // --- GAGAL DISIMPAN ---
            // Redirect ke halaman ini sendiri dengan status 'gagal'
            header('Location: layanan-kontak.php?status=gagal#kontak');
            exit(); // Penting!
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Layanan & Kontak - Nusafora Trip</title>
    
    <link rel="stylesheet" href="style.css">
    
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
</head>
<body>

    <header class="header-fixed">
        <div class="container header-container">
            <h1 class="logo">Nusafora Trip</h1>
            
            <nav class="main-nav">
                <a href="index.html">Home</a>
                <a href="layanan-kontak.php" class="active">Layanan & Kontak</a> 
                <a href="tentang.html">About</a>
            </nav>
            <button class="mobile-menu-toggle" aria-label="Buka menu">&#9776;</button>
        </div>
        
        <nav class="mobile-nav">
            <a href="index.html">Home</a>
            <a href="tentang.html">Tentang</a>
            <a href="layanan-kontak.php" class="active">Layanan & Kontak</a>
        </nav>
    </header>

    <section class="page-header" style="background-image: url('https://images.pexels.com/photos/1004584/pexels-photo-1004584.jpeg');">
        <div class="hero-overlay"></div>
        <div class="container text-center" data-aos="fade-in">
            <h2>Layanan & Kontak</h2>
        </div>
    </section>

    <section id="layanan" class="page-section" data-aos="fade-up">
        <div class="container text-center">
            <h3>Layanan Terbaik Kami</h3>
            <p style="max-width: 700px; margin-left: auto; margin-right: auto;">
                Kami menyediakan tiga jenis layanan utama untuk memastikan petualangan Anda 
                berjalan sempurna sesuai impian Anda.
            </p>
            <div class="grid-3" style="margin-top: 2rem;">
                <div class="card" data-aos="fade-up" data-aos-delay="100">
                    <h4 class="text-primary">Paket Wisata</h4>
                    <p>Pilih dari berbagai paket perjalanan yang telah kami rancang dengan cermat ke destinasi terbaik di Nusantara. Semua sudah termasuk akomodasi, transportasi, dan pemandu.</p>
                </div>
                <div class="card" data-aos="fade-up" data-aos-delay="200">
                    <h4 class="text-primary">Open Trip</h4>
                    <p>Pilihan hemat untuk solo traveler atau grup kecil. Bergabunglah dengan wisatawan lain, dapatkan teman baru, dan bagi biaya perjalanan bersama-sama.</p>
                </div>
                <div class="card" data-aos="fade-up" data-aos-delay="300">
                    <h4 class="text-primary">Private Tour</h4>
                    <p>Nikmati perjalanan eksklusif yang dirancang khusus untuk Anda. Tentukan jadwal, destinasi, dan gaya perjalanan Anda sendiri dengan layanan personal penuh.</p>
                </div>
            </div>
        </div>
    </section>

    <section id="kontak" class="page-section bg-light">
        <div class="container" style="max-width: 800px;">
            <div class="text-center">
                <h3>Hubungi Kami</h3>
                <p>Ada pertanyaan atau ingin merencanakan perjalanan? Kirimkan pesan kepada kami!</p>
            </div>

            <form action="layanan-kontak.php#kontak" method="POST" class="contact-form">
                
                <?php echo $statusMsg; ?>

                <div class="form-group">
                    <label for="nama">Nama Lengkap:</label>
                    <input type="text" id="nama" name="nama" required>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="pesan">Pesan Anda:</label>
                    <textarea id="pesan" name="pesan" rows="6" required></textarea>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-primary">Kirim Pesan</button>
                </div>
            </form>
        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <p>&copy; 2025 Nusafora Trip. Dibuat dengan sepenuh hati.</p>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    
    <script src="script.js"></script>
</body>
</html>