$(document).ready(function() {

    AOS.init({
        duration: 1000, 
        once: true,       
    });

    $('.mobile-menu-toggle').click(function() {
        $('.mobile-nav').slideToggle(300);
    });

    $(window).scroll(function() {
        if ($(this).scrollTop() > 50) {
            $('.header-fixed').addClass('scrolled');
        } else {
            $('.header-fixed').removeClass('scrolled');
        }
    });

    $('a[href*="#"]').on('click', function(e) {
        
        if (this.pathname === window.location.pathname) {
            
            e.preventDefault();

            var target = $(this.hash);

            if (target.length) {
                var headerHeight = $('.header-fixed').outerHeight();
                
                $('html, body').animate({
                    scrollTop: target.offset().top - headerHeight 
                }, 800); 
            }
        }
    });

});
